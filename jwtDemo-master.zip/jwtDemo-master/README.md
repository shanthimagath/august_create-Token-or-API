# jwtDemo
Token-based API authentication with Spring and JWT

This project is a sample for a blog post published in Softtek:

* Spanish version: https://blog.softtek.com/es/autenticando-apis-con-spring-y-jwt
* English version: https://blog.softtek.com/en/token-based-api-authentication-with-spring-and-jwt
